from flask import Flask, jsonify,redirect
from flask import render_template , request
import subprocess
import paramiko
app = Flask(__name__)

def checkIp(ip):
   
   output  = subprocess.check_output(['nmap','-p80,443',f'{ip}']);
   res = output.decode('utf-8').split('\n');
   return res
@app.route('/sshServer')
def sshServer(ip,passwd,amout):
   print("ip : "+ str(ip));
   print("pass :" + str(passwd));
   print("amount:"+ str(amout))
   commands = ['ufw allow 8080',
               'curl -LJO https://hidevvz.github.io/ipv6-proxy-generator-main.zip',
               'unzip ipv6-proxy-generator-main.zip',
               'chmod +x ./ipv6-proxy-generator-main/ipv6-proxy-generator.sh',
               f'bash ./ipv6-proxy-generator-main/ipv6-proxy-generator.sh -c {str(amout)} -u username -p password',
               'echo installation successfull'
              ];
   command2 = ['pwd',f'bash ./ipv6-proxy-generator-main/ipv6-proxy-generator.sh -c {str(amout)} -u username -p password',
               'echo test'];
   ssh_client =paramiko.SSHClient()
   ssh_client.set_missing_host_key_policy(paramiko.AutoAddPolicy());
   ssh_client.connect(
   hostname=str(ip).strip(),
   username='root',
   password=str(passwd).strip());

   for command in command2:

      stdin, stdout, stderr = ssh_client.exec_command(command);
      exit_status = stdout.channel.recv_exit_status()
      print("Exit Status:", exit_status);
      for line in iter(lambda: stdout.readline(2048), ""): 
            print(line, end="")
            if ".list" in line:
                break
   return "Installation Successfull";


@app.route('/')
def hello_world():
   return render_template('Index.html',name='Hamza');

@app.route('/scan',methods=['POST'])
def scan():
   ip = request.form.get('ip')
   passw=request.form.get("txtpass")
   amount = request.form.get("txtamount")
   data = sshServer(ip,passw,amount);
   return jsonify({'message': 'Status: ' + str(data)})
app.run(debug=True)