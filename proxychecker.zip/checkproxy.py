import subprocess

# Function to check if a proxy is live using curl with username and password
def is_proxy_live_with_curl(proxy):
    url = "http://www.ipv6.google.com"  # Replace with the URL you want to test
    proxy_parts = proxy.split(":")
    username = proxy_parts[2]
    password = proxy_parts[3]
    
    # Construct the curl command with the proxy, username, and password
    curl_command = [
        "curl", 
        "-x", f"http://{proxy_parts[0]}:{proxy_parts[1]}",
        "-m", "10",  # Timeout in seconds (adjust as needed)
        "--proxy-user", f"{username}:{password}",
        url
    ]
    
    try:
        subprocess.check_output(curl_command)
        return True
    except subprocess.CalledProcessError:
        pass
    return False

# Read proxies from a file
def read_proxies_from_file(file_path):
    proxies = []
    with open(file_path, "r") as file:
        for line in file:
            proxy = line.strip()
            proxies.append(proxy)
    return proxies

# Write live proxies to a new file
def write_live_proxies_to_file(proxies, output_file):
    with open(output_file, "w") as file:
        for proxy in proxies:
            file.write(f"{proxy}\n")

if __name__ == "__main__":
    file_path = "proxy.txt"  # Replace with the path to your proxy file
    proxies = read_proxies_from_file(file_path)
    
    live_proxies = []

    for proxy in proxies:
        if is_proxy_live_with_curl(proxy):
            print(f"Live proxy: {proxy}")
            live_proxies.append(proxy)

    print(f"Live Proxies: {len(live_proxies)}")
    
    # Write live proxies to a new file called live.txt
    write_live_proxies_to_file(live_proxies, "live.txt")
